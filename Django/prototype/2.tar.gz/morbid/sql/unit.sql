--
INSERT INTO morbid_unit (name, value) VALUES ('Days', 'd');
INSERT INTO morbid_unit (name, value) VALUES ('Percent', '%%');