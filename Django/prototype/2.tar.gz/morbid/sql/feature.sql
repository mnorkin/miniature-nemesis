--
INSERT INTO morbid_feature (name, unit_id, display_in_frontpage, description) VALUES 
  ('Accuracy',            '2', '1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sit amet neque in turpis adipiscing mollis dignissim commodo neque.'),
  ('Closeness',           '2', '1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sit amet neque in turpis adipiscing mollis dignissim commodo neque.'),
  ('Difference',          '2', '1', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sit amet neque in turpis adipiscing mollis dignissim commodo neque.'),
  ('Profitability',       '2', '0', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sit amet neque in turpis adipiscing mollis dignissim commodo neque.'),
  ('Max. Profitability',  '2', '0', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sit amet neque in turpis adipiscing mollis dignissim commodo neque.'),
  ('Impact to market',    '2', '0', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sit amet neque in turpis adipiscing mollis dignissim commodo neque.'),
  ('Reach time',          '1', '0', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sit amet neque in turpis adipiscing mollis dignissim commodo neque.');