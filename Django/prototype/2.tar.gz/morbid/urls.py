from django.conf.urls import patterns, include, url

# urlpatterns = patterns('morbid.views',
# 	url(r'^$', 'index'),
# 	url(r'^analytic/(?P<slug>\w+)/$', 'analytic'),
# 	url(r'^ticker/(?P<slug>\w+)/$', 'ticker'),

# 	url(r'^feature_by_ticker/(?P<slug>\w+)/(?P<feature_id>\d+)/$', 'feature_by_ticker'), # JSON only
# 	url(r'^feature_by_analytic/(?P<slug>\w+)/(?P<feature_id>\d+)/$', 'feature_by_analytic'), # JSON only
# 	url(r'^search/(?P<search_me>\w+)/$', 'search'), # JSON only
# )